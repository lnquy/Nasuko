package main

import "fmt"

type User struct {
	Name string
}

func main() {
	user := retUser()
	fmt.Printf("Type: %T\nValue: %v", user, user)
}

func retUser() *User {
	return &User {
		Name: "lnquy",
	}
}