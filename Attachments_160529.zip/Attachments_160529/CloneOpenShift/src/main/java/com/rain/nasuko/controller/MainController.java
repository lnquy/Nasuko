package com.rain.nasuko.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rain.nasuko.entity.LeechRequest;
import com.rain.nasuko.service.downloadmanager.DownloadManager;
import com.rain.nasuko.service.downloadmanager.DownloadMission;
import com.rain.nasuko.service.downloadmanager.DownloadUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

/**
 * Created by RA!N on 5/27/2016.
 */
@Controller
public class MainController {

    @RequestMapping(value = "/")
    public String displayMainpage(Model model) {
        model.addAttribute(new LeechRequest());
        return "main";
    }

    private HashMap<String, String> sessionFileName = new HashMap<String, String>();
    @RequestMapping(value = "/submitForm.web", method = RequestMethod.POST, produces = "application/json", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public@ResponseBody String processLeechRequest(@RequestBody final LeechRequest leechRequest, final HttpServletRequest request) {
        System.out.println("Leech request URL: " + leechRequest.getLink());

            if (isValidUrl(request.getSession().getId(), leechRequest.getLink())) {
                System.out.println("Valid URL!");

                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        leechURLToFile(request.getSession().getId(), leechRequest.getLink());
                    }
                });
                thread.start();
                return "true";
            }
            System.out.println("Invalid URL!");
            return "false";
    }

    @RequestMapping(value = "/progress")
    public ModelAndView retAjax() {
        return new ModelAndView("progress");
    }

    // TODO
    @RequestMapping(value = "/path")
    public ModelAndView getPath() {
        String path = "User dir: " + System.getProperty("user.dir");
        Path currentRelativePath = Paths.get("");
        path += "<br/>NIO path: " +  currentRelativePath.toAbsolutePath().toString();
        path += "<br/>Root data dir: " + System.getenv("OPENSHIFT_DATA_DIR");
        ModelAndView mav = new ModelAndView("post");
        mav.addObject("post_message", path);
        return mav;
    }


    HashMap<String, DownloadMission> sessionDownload = new HashMap<String, DownloadMission>();
    @RequestMapping(value = "/leech", method = RequestMethod.GET)
    public @ResponseBody String getLeechProgress(HttpServletRequest request) {
        System.out.println("getLeech called!");
        DownloadMission mission = sessionDownload.get(request.getSession().getId());
        if (mission.isFinished())
            return "";
//        if (mission == null || mission.isFinished())
//            return "Finished or null!";
//        return "isFinished: " + mission.isFinished() + "<br/>Current speed: "
//                        + mission.getReadableSpeed()
//                        + "<br/>Downloaded size: "
//                        + mission.getDownloadedSize();
        HashMap<String, String> retMap = new HashMap<String, String>();
        retMap.put("isFinished", mission.isFinished() + "");
        retMap.put("currSpeed", mission.getReadableSpeed());
        retMap.put("downloadedSize", DownloadUtils.getReadableSize(mission.getDownloadedSize()));
        retMap.put("fileSize", DownloadUtils.getReadableSize(mission.getFileSize()) + "");
        retMap.put("percentage", (100 * mission.getDownloadedSize() / mission.getFileSize()) + "%");
        if (mission.getDownloadedSize() == mission.getFileSize())
            mission.setIsFinished(true);

        ObjectMapper mapper = new ObjectMapper();
        String json = "";
        try {
            json = mapper.writeValueAsString(retMap);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        System.out.println(json);
        return json;
    }

    // TODO: Put this code in an asynctask and call it there
    // TODO: Is this really necessary?
    public boolean isValidUrl(String sessionId, String srcUrl) {
        try {
            String finalLink = getLastRedirectUrl(srcUrl, "");
            URL url = new URL(finalLink);
            String[] urlPaths = url.getPath().split("/");
            String fileName = "noname_file";
            if (urlPaths.length > 0) {
                fileName = urlPaths[urlPaths.length - 1];
            }
            System.out.println("File name parsed from URL path: " + fileName);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setInstanceFollowRedirects(true);
            conn.setConnectTimeout(10000);
            conn.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
            conn.addRequestProperty("User-Agent", "Mozilla");
            conn.addRequestProperty("Referer", "google.com");
            conn.connect();

            if (conn.getHeaderField("Content-Disposition") != null
                    && !"".equals(conn.getHeaderField("Content-Disposition"))) {
                fileName = conn.getHeaderField("Content-Disposition");
            }
            System.out.println("Final file name: " + fileName);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                // Match filename with session
                sessionFileName.put(sessionId, fileName);
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private String getLastRedirectUrl(String srcLink, String cookies) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(srcLink).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setReadTimeout(5000);

        conn.addRequestProperty("Accept-Language", "en-US,en;q=0.8");
        conn.addRequestProperty("User-Agent", "Mozilla");
        conn.addRequestProperty("Referer", "google.com");
        if (!"".equals(cookies)) {
            conn.addRequestProperty("Cookie", cookies);
        }
        conn.connect();
        conn.getInputStream();

        // If redirect
        if (conn.getResponseCode() == HttpURLConnection.HTTP_MOVED_PERM || conn.getResponseCode() == HttpURLConnection.HTTP_MOVED_TEMP) {
            String redirectUrl = conn.getHeaderField("Location");
            String redirectCookies = conn.getHeaderField("Set-Cookie");
            // Recursion
            System.out.println(">>> Redirect link: " + redirectUrl);
            return getLastRedirectUrl(redirectUrl, redirectCookies);
        }

        System.out.println(">>> Final link: " + srcLink);
        return srcLink;
    }

    private void leechURLToFile(String sessionId, String srcUrl) {
        DownloadManager downloadManager = DownloadManager.getInstance();
        // TODO: Change default directory
        String saveDirectory = System.getenv("OPENSHIFT_DATA_DIR") + File.separator + "downloaded" + File.separator;
//        String saveDirectory = "D:\\NasukoDownloadedFile";
        String fileName = sessionFileName.get(sessionId);
        try {
            DownloadMission mission = new DownloadMission(srcUrl,
                    saveDirectory, fileName);
            sessionDownload.put(sessionId, mission);
            downloadManager.addMission(mission);
            downloadManager.start();
//            int counter = 0;
//            while (!downloadManager.isTaskFinished(mission.getMissionID())) {
//                // System.out.println("The mission has finished :"
//                // + mission.getReadableSize() + "Active Count:"
//                // + mission.getActiveTheadCount() + " speed:"
//                // + mission.getReadableSpeed() + " status:"
//                // + mission.isFinished() + " AverageSpeed:"
//                // + mission.getReadableAverageSpeed() + " MaxSpeed:"
//                // + mission.getReadableMaxSpeed() + " Time:"
//                // + mission.getTimePassed() + "s");
//                System.out.println("Downloader information Speed:"
//                        + downloadManager.getReadableTotalSpeed()
//                        + " Down Size:"
//                        + downloadManager.getReadableDownloadSize());
//                Thread.sleep(1000);
//                counter++;
//                // if (counter == 6) {
//                // mission.pause();
//                // }
//                // if (counter == 11) {
//                // downloadManager.start();
//                // }
//            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }
//        catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }
}
