package com.rain.nasuko.entity;

import java.io.Serializable;

/**
 * Created by RA!N on 5/27/2016.
 */
public class LeechRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    // Default constructor for parsing JSON from request
    public LeechRequest() {
    }


    public LeechRequest(String link) {
        super();
        this.link = link;
    }

    private String link;

    public String getLink() {
        return link;
    }
    public void setLink(String link) {
        this.link = link;
    }
}
